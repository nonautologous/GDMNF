import Dataset2
import numpy as np
from mne.io import read_raw_edf
from mne.utils import verbose

class Innitiatedataset(BaseDatasetD):
    """Base BNCI dataset"""
    dict
    def _get_single_subject_data(self, subject,f_array):
        """return data for a single subject"""
        sessions = load_dataD(subject,f_array)
        return sessions

class BNCIlike(Innitiatedataset):
    def __init__(self):
        super().__init__(
            subjects=list(range(1)),
            sessions_per_subject=2,
            events={'left_hand': 1, 'right_hand': 2, 'feet': 3, 'tongue': 4},
            code='001-2014',
            interval=[2, 6],
            paradigm='imagery',
            doi='10.3389/fnins.2012.00055')

def load_dataD(subject, Sn=False,filenames=[None],verbose=None):
    """Load data for dataset."""
    sessions = {}
    if Sn==False:
        c=0
        for f in filenames:
            c=c+1
            edf=mne.io.read_raw_edf(f,preload=True)
            sessions['session_%s' %c]={'run_%d' % c:edf}
    else :        
        ch_names = [
            'Fz', 'FC3', 'FC1', 'FCz', 'FC2', 'FC4', 'C5', 'C3', 'C1', 'Cz', 'C2',
            'C4', 'C6', 'CP3', 'CP1', 'CPz', 'CP2', 'CP4', 'P1', 'Pz', 'P2', 'POz',
            'EOG1', 'EOG2', 'EOG3'
        ]
        ch_types = ['eeg'] * 22 + ['eog'] * 3
        for r in ['T', 'E']:
            url = '{u}001-2014/A{s:02d}{r}.mat'.format(u=base_url, s=subject, r=r)
            filename = data_path(url, path, force_update, update_path)
            runs, ev = _convert_mi(filename[0], ch_names, ch_types)
            sessions['session_%s' % r] = {'run_%d' % ii: run
                                      for ii, run in enumerate(runs)}
    return sessions
def _convert_mi(filename, ch_names, ch_types):
    '''
    Processes (Graz) motor imagery data from MAT files, returns list of
    recording runs.
    '''

    runs = []
    event_id = {}
    data = mne.io.read_raw_edf(filename)
    if isinstance(data['data'], np.ndarray):
        run_array = data['data']
    else:
        run_array = [data['data']]

    for run in run_array:
        raw, evd = _convert_run(run, ch_names, ch_types, None)
        if raw is None:
            continue
        runs.append(raw)
        event_id.update(evd)
    # change labels to match rest
    standardize_keys(event_id)
    return runs, event_id
@verbose
def _convert_run(run, ch_names=None, ch_types=None, verbose=None):
    """Convert one run to raw."""
    # parse eeg data
    event_id = {}
    n_chan = run.X.shape[1]
    montage = make_standard_montage('standard_1005')
    eeg_data = 1e-6 * run.X
    sfreq = run.fs

    if not ch_names:
        ch_names = ['EEG%d' % ch for ch in range(1, n_chan + 1)]
        montage = None  # no montage

    if not ch_types:
        ch_types = ['eeg'] * n_chan

    trigger = np.zeros((len(eeg_data), 1))
    # some runs does not contains trials i.e baseline runs
    if len(run.trial) > 0:
        trigger[run.trial - 1, 0] = run.y

    eeg_data = np.c_[eeg_data, trigger]
    ch_names = ch_names + ['stim']
    ch_types = ch_types + ['stim']
    event_id = {ev: (ii + 1) for ii, ev in enumerate(run.classes)}
    info = create_info(
        ch_names=ch_names, ch_types=ch_types, sfreq=sfreq, montage=montage)
    raw = RawArray(data=eeg_data.T, info=info, verbose=verbose)
    return raw, event_id